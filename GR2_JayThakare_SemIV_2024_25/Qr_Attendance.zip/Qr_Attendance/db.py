import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='Jay@1509',
        database='smart_attendance',
        auth_plugin="mysql_native_password"
    )
