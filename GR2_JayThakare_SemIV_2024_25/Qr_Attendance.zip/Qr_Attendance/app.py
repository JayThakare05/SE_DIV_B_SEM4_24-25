from flask import Flask, render_template, request, redirect, session, flash, url_for,jsonify
from flask_socketio import SocketIO
from db import get_connection
import qrcode
import os
import pandas as pd
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'secret!'  
socketio = SocketIO(app)

scanned_by = None

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        role = request.form['role']
        userid = request.form['userid']
        password = request.form['password']
        class_name = request.form.get('class_name')

        conn = get_connection()
        cursor = conn.cursor(dictionary=True)

        if role == 'admin':
            cursor.execute("SELECT * FROM admin WHERE userid=%s AND password=%s", (userid, password))
            result = cursor.fetchone()
            if result:
                session['role'] = 'admin'
                session['userid'] = userid
                return redirect('/show_qr')
            else:
                flash("Invalid Admin Credentials")

        elif role == 'student' and class_name:
            query = f"SELECT * FROM `{class_name}` WHERE userid=%s AND password=%s"
            cursor.execute(query, (userid, password))
            result = cursor.fetchone()
            if result:
                session['role'] = 'student'
                session['userid'] = userid
                session['class'] = class_name
                return redirect('/scan_qr')
            else:
                flash("Invalid Student Credentials or Class")
        
        conn.close()

    return render_template('login.html')

@app.route('/show_qr')
def show_qr():
    # Generate QR code and save
    data = "scan_this_qr_123"
    img = qrcode.make(data)
    img.save("static/qr.png")
    return render_template('show_qr.html')

@app.route('/scan_qr')
def scan_qr():
    return render_template('scan_qr.html')

@app.route('/submit_scan', methods=['POST'])
def submit_scan():
    userid = session.get('userid')
    class_name = session.get('class')

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    query = f"SELECT * FROM `{class_name}` WHERE userid=%s"
    cursor.execute(query, (userid,))
    result = cursor.fetchone()
    conn.close()

    if result:
        student_name = result['name']
        student_roll = result['roll_no']

        # Emit the scan event to all connected clients
        socketio.emit('qr_scanned', {
            'name': student_name,
            'roll_no': student_roll,
            'class_name': class_name
        })

        return 'Scan recorded', 200
    else:
        return 'Student not found', 404

@app.route('/generate_qr', methods=['POST'])
def generate_qr():
    data = request.get_json()
    subject = data['subject']
    class_name = data['class_name']
    time = data['time']
    hours = data['hours']

    qr_name = f"{subject}_{class_name}_{time}_{hours}".replace(":", "-")
    qr_data = f"{subject}|{class_name}|{time}|{hours}"

    img = qrcode.make(qr_data)
    img.save(f"static/{qr_name}.png")

    return jsonify({"status": "success", "filename": qr_name})
@app.route('/save_attendance', methods=['POST'])
def save_attendance():
    data = request.json
    qr_name = data['qr_name']
    students = data['students']

    if not students:
        return jsonify({'message': 'No students scanned.'}), 400

    attendance_list = []
    for s in students:
        # Expected format: "Name (RollNo) - Class"
        try:
            name_part, class_name = s.split(" - ")
            name, roll = name_part.rsplit(" (", 1)
            roll = roll.replace(")", "")
            attendance_list.append({'Name': name.strip(), 'Roll No': roll.strip(), 'Class': class_name.strip()})
        except ValueError:
            continue

    df = pd.DataFrame(attendance_list)
    
    folder = os.path.join("Excel", qr_name.split("_")[1])  # Extract class name
    os.makedirs(folder, exist_ok=True)
    filename = os.path.join(folder, f"{qr_name}.xlsx")

    df.to_excel(filename, index=False)
    return jsonify({'message': 'Saved successfully!'})
if __name__ == '__main__':
    socketio.run(app, debug=True)
