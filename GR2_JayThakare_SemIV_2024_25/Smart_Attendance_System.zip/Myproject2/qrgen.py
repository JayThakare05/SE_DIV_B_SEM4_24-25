import qrcode
import os
import pandas as pd
from datetime import datetime
from io import BytesIO
from db import get_all_students

EXCEL_FOLDER = "Excel"
QR_FOLDER = os.path.join(EXCEL_FOLDER, "QR")
os.makedirs(EXCEL_FOLDER, exist_ok=True)
os.makedirs(QR_FOLDER, exist_ok=True)

def generate_qr(class_name, date, subject, time_str):
    """Generates a QR code and creates an attendance sheet."""
    file_name = f"{class_name}_{date}_{subject}_1hr.xlsx"  
    class_folder = os.path.join(EXCEL_FOLDER, class_name)
    os.makedirs(class_folder, exist_ok=True)
    file_path = os.path.join(class_folder, file_name)

    # Create an empty Excel file with student names
    students = get_all_students(class_name)  # Fetch students from DB
    if students:
        df = pd.DataFrame(students, columns=["Roll No", "Name"])
        df["Status"] = "Absent"  # Initially mark everyone absent
        df.to_excel(file_path, index=False)

    # Generate QR Code Data
    qr_data = f"{class_name}|{date}|{subject}|{time_str}"
    qr = qrcode.make(qr_data)
    qr_path = os.path.join(class_folder, f"{class_name}_{date}_{subject}_qr.png")
    qr.save(qr_path)

    return qr_path

def mark_attendance_from_qr(qr_data, student_name="Scanned Student"):
    """Mark attendance when QR is scanned."""
    parts = qr_data.split(", ")
    class_name = parts[0].split(": ")[1]
    date = parts[1].split(": ")[1]
    subject = parts[2].split(": ")[1]

    file_name = f"{date}.xlsx"
    file_path = os.path.join(EXCEL_FOLDER, file_name)

    # Load or create attendance file
    if os.path.exists(file_path):
        df = pd.read_excel(file_path)
    else:
        df = pd.DataFrame(columns=["Student Name", "Class", "Subject", "Date", "Time"])

    now = datetime.now().strftime("%H:%M:%S")
    new_entry = pd.DataFrame([[student_name, class_name, subject, date, now]], columns=df.columns)

    df = pd.concat([df, new_entry], ignore_index=True)
    df.to_excel(file_path, index=False)

    return f"✅ Attendance marked for {student_name} in {class_name} ({subject})"
