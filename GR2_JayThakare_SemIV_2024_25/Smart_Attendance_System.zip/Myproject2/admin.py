import streamlit as st
import os
import pandas as pd
import time
from face_recognition_code import capture_attendance
from qrgen import generate_qr
from db import create_or_reset_attendance_record, fetch_attendance_record

def update_query_params(page_name):
    """Update the query parameters for navigation."""
    if st.session_state.page != page_name: 
        st.session_state.page = page_name
        st.query_params["page"] = page_name
        st.rerun()

EXCEL_FOLDER = "Excel"
os.makedirs(EXCEL_FOLDER, exist_ok=True)

def show_attendance_report():
    """Displays attendance reports based on class name input."""
    class_name = st.text_input("\U0001F3EB Enter Class Name:", "")
    if not class_name:
        st.warning("⚠ Please enter a class name to proceed.")
        return
    class_folder = os.path.join(EXCEL_FOLDER, class_name)
    if not os.path.exists(class_folder):
        st.error(f"❌ No records found for class '{class_name}'.")
        return
    files = [f for f in os.listdir(class_folder) if f.endswith(".xlsx")]
    if not files:
        st.warning(f"⚠ No attendance records found for '{class_name}'.")
        return
    selected_file = st.selectbox("\U0001F4DC Select an attendance file:", files)
    if selected_file:
        file_path = os.path.join(class_folder, selected_file)
        with open(file_path, "rb") as f:
            st.download_button(
                label="\U0001F4E5 Download Attendance Report",
                data=f,
                file_name=selected_file,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        df = pd.read_excel(file_path)
        st.dataframe(df)

def admin_panel():
    """Admin Dashboard with Face Recognition and QR Code Generation"""
    st.title("\U0001F6E0️ Admin Dashboard")
    if "userid" in st.session_state:
        st.subheader(f"Welcome, {st.session_state.userid}!")

    tab1, tab2 = st.tabs(["\U0001F4CB Take Attendance", "\U0001F4CA View Reports"])
    
    with tab1:
        st.subheader("\U0001F4F7 Facial Recognition / QR Attendance")
        class_name = st.text_input("\U0001F4CC Class Name")
        subject = st.text_input("\U0001F4D6 Subject Name")

        col1, col2 = st.columns(2)
        with col1:
            date = st.date_input("\U0001F4C5 Date").strftime("%Y-%m-%d")
        with col2:
            time_str = st.text_input("⏰ Time (HH:MM 24hr format)", placeholder="Enter time like 14:30")

        duration = st.number_input("⌛ Duration (hrs)", min_value=0.5, max_value=8.0, value=1.0, step=0.5)

        st.markdown("---")
        
        col1, col2 = st.columns(2)
        with col1:
            if st.button("\U0001F4F7 Start Face Recognition"):
                if class_name and subject and time_str:
                    capture_attendance(class_name, date, duration, subject, time_str)
                else:
                    st.error("❌ Please enter a valid class name, subject, and time.")

        with col2:
            if st.button("\U0001F5A8 Generate QR Code"):
                if class_name and subject and time_str:
                    # Step 1: Reset attendance record in DB
                    create_or_reset_attendance_record()

                    # Step 2: Generate QR
                    qr_path = generate_qr(class_name, date, subject, time_str)
                    qr_filename = os.path.splitext(os.path.basename(qr_path))[0]

                    # Step 3: Save session variables
                    st.session_state.qr_path = qr_path
                    st.session_state.qr_expiry = time.time() + 60  # QR valid for 60 seconds
                    st.session_state.qr_name = qr_filename
                    st.session_state.qr_exported = False
                    st.success("✅ QR Code generated and attendance record reset.")
                else:
                    st.error("❌ Please enter a valid class name, subject, and time.")

        # Attendance notification from students
        if "attendance_notifications" in st.session_state:
            for notification in st.session_state["attendance_notifications"]:
                st.warning(notification)

        # Show QR with countdown if still active
        if "qr_path" in st.session_state:
            current_time = time.time()
            expiry_time = st.session_state.qr_expiry
            remaining_time = int(expiry_time - current_time)

            if remaining_time > 0:
                minutes, seconds = divmod(remaining_time, 60)
                st.image(st.session_state.qr_path, caption="Scan this QR to mark attendance", width=250)
                st.info(f"⏳ QR Code valid for: **{minutes:02}:{seconds:02}**")
                # Rerun every second to update countdown
                st.rerun()

            else:
                st.warning("⚠ QR Code has expired. Generate a new one.")

                # Export data only once
                if not st.session_state.get("qr_exported"):
                    df = fetch_attendance_record()
                    if not df.empty:
                        class_folder = os.path.join(EXCEL_FOLDER, class_name)
                        os.makedirs(class_folder, exist_ok=True)
                        filename = f"{st.session_state.qr_name}.xlsx"
                        save_path = os.path.join(class_folder, filename)
                        df.to_excel(save_path, index=False)
                        st.success(f"✅ Attendance data saved to {filename}")
                    else:
                        st.info("ℹ No attendance data found to export.")
                    st.session_state.qr_exported = True

        if "latest_attendance" in st.session_state:
            st.info(st.session_state["latest_attendance"])
    
    with tab2:
        st.subheader("\U0001F4CA Attendance Reports")
        show_attendance_report()

    st.sidebar.header("\U0001F4C2 Recent Attendance Sessions")
    if "attendance_logs" in st.session_state:
        for log in st.session_state.attendance_logs:
            st.sidebar.text(log)
    else:
        st.sidebar.text("No attendance sessions yet")

    if st.sidebar.button("\U0001F519 Logout"):
        update_query_params("login")
