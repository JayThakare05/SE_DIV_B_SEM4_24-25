import os
import pandas as pd
EXCEL_FOLDER = "Excel"
os.makedirs(EXCEL_FOLDER, exist_ok=True)
def save_attendance_to_excel(class_name, date, hrs, subject, attendance_data):
    file_name = f"{date}_{hrs}hrs_{subject}.xlsx"
    os.makedirs(class_name, exist_ok=True)
    file_path = os.path.join(class_name, file_name)
    file_path = os.path.join(EXCEL_FOLDER, file_path)
    df = pd.DataFrame(attendance_data, columns=["Roll No", "Status"])
    df.to_excel(file_path, index=False)
    return file_path 
