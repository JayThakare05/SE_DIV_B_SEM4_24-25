import streamlit as st
from db import register_user, verify_login
import admin
import student

st.set_page_config(
    page_title="Smart Attendance System", 
    page_icon="🔑",
    layout="wide"
)

# Check query parameters for navigation
query_params = st.query_params

# Set default session state
if "page" not in st.session_state:
    st.session_state.page = query_params.get("page", "login")  # Default to login page
    st.session_state.logged_in = False
    st.session_state.role = None
    st.session_state.userid = None
    st.session_state.attendance_logs = []

def update_query_params(page_name):
    """Update the query parameters for navigation."""
    if st.session_state.page != page_name:  # Prevent unnecessary reruns
        st.session_state.page = page_name
        st.query_params["page"] = page_name
        st.rerun()

def login_page():
    """Login Page"""
    col1, col2 = st.columns([1, 1])
    with col1:
        st.title("🔐 Smart Attendance System")
        st.header("User Login")
        role = st.radio("Select Role", ["User", "Admin"], horizontal=True)
        userid = st.text_input("User ID", placeholder="Enter your User ID")
        class_name = None
        if role == "User":
            class_name = st.text_input("Class Name", placeholder="Enter your class")
        password = st.text_input("Password", type="password", placeholder="Enter your password", key="password")

        if st.button("Login"):
            if role == "User" and not class_name:
                st.error("❌ Please enter your class name.")
            else:
                user = verify_login(userid, password, role, class_name)
                if user:
                    st.success(f"✅ {role} Login Successful!")
                    st.session_state.logged_in = True
                    st.session_state.role = role
                    st.session_state.userid = userid
                    st.session_state.class_name = class_name if role == "User" else None
                    update_query_params("dashboard")
                else:
                    st.error("❌ Invalid credentials. Please try again.")

        if st.button("Don't have an account? Register here"):
            update_query_params("register")

    with col2:
        st.image("attendance_system.png", caption="Face Recognition Attendance System", width=400)

def register_page():
    """Registration Page"""
    st.title("📝 Register New Account")
    role = st.radio("Register as", ["User", "Admin"], horizontal=True)
    col1, col2 = st.columns(2)
    with col1:
        name = st.text_input("Full Name", placeholder="Enter your full name")
        userid = st.text_input("User ID", placeholder="Choose a unique User ID")
        class_name = st.text_input("Class", placeholder="Enter your class (optional)") if role == "User" else None
    with col2:
        roll_no = st.text_input("Roll No.", placeholder="Enter your roll number (optional)") if role == "User" else None
        password = st.text_input("Create Password", type="password", placeholder="Enter a strong password")
        confirm_password = st.text_input("Confirm Password", type="password", placeholder="Re-enter your password")

    photo = st.file_uploader("Upload Your Photo", type=["jpg", "png", "jpeg"])
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Register"):
            if name and userid and password and confirm_password:
                if password == confirm_password:
                    if photo is not None:
                        result = register_user(
                            name, userid, role, class_name if role == "User" else None, 
                            roll_no if role == "User" else None, password, photo.read()
                        )
                        if "✅" in result:
                            st.success(result)
                            st.info("Please login with your new account")
                            import time
                            time.sleep(2)
                            update_query_params("login")
                        else:
                            st.error(result)
                    else:
                        st.error("❌ Please upload a photo for facial recognition.")
                else:
                    st.error("❌ Passwords do not match. Please try again.")
            else:
                st.error("❌ Please fill all required fields.")
    with col2:
        if st.button("Already have an account? Login here"):
            update_query_params("login")

def dashboard_page():
    """Dashboard Page"""
    if st.session_state.role == "Admin":
        admin.admin_panel() 
    elif st.session_state.role == "User":
        student.student_panel()

# **Page Routing Logic**
if st.session_state.page == "login":
    login_page()
elif st.session_state.page == "register":
    register_page()
elif st.session_state.page == "dashboard":
    dashboard_page()
