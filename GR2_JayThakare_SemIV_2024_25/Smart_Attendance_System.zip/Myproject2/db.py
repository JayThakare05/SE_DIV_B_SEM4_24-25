import mysql.connector
import pandas as pd
def connect_db():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Jay@1509",  # Consider storing credentials in environment variables
            database="smart_attendance",
            auth_plugin="mysql_native_password"
        )
        return conn
    except mysql.connector.Error as err:
        print(f"Database Connection Error: {err}")
        return None
def initialize_database():
    conn = connect_db()
    if not conn:
        return "❌ Database connection failed."

    cursor = conn.cursor()
    try:
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS admin (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                userid VARCHAR(50) UNIQUE NOT NULL,
                password VARCHAR(100) NOT NULL,
                photo LONGBLOB
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id INT AUTO_INCREMENT PRIMARY KEY,
                student_id VARCHAR(50) NOT NULL,
                class_name VARCHAR(50) NOT NULL,
                subject VARCHAR(100) NOT NULL,
                date_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(20) DEFAULT 'Present',
                FOREIGN KEY (student_id) REFERENCES student(userid) ON DELETE CASCADE
            )
        """)
        conn.commit()
        return "✅ Database initialized successfully."
    except mysql.connector.Error as err:
        return f"❌ Database Error: {err}"
    finally:
        cursor.close()
        conn.close()
def register_user(name, userid, role, class_name, roll_no, password, photo):
    conn = connect_db()
    if not conn:
        return "❌ Database connection failed."
    conn.autocommit = True 
    cursor = conn.cursor()
    
    try:
        if role == "Admin":
            cursor.execute("SELECT * FROM admin WHERE userid = %s", (userid,))
            if cursor.fetchone():
                return "❌ Admin account already exists!"
            cursor.execute("INSERT INTO admin (name, userid, password, photo) VALUES (%s, %s, %s, %s)",
                           (name, userid, password, photo))
        elif role == "User":
            if not class_name or not roll_no:
                return "❌ Class Name and Roll Number are required for students."
            table_name = class_name.replace(" ", "_").replace("-", "_") 
            create_table_query = f"""
                CREATE TABLE IF NOT EXISTS {table_name} (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(100) NOT NULL,
                    userid VARCHAR(50) UNIQUE NOT NULL,
                    roll_no VARCHAR(50) UNIQUE NOT NULL,
                    password VARCHAR(100) NOT NULL,
                    photo LONGBLOB NOT NULL
                )
            """
            cursor.execute(create_table_query)
            conn.commit()
            cursor.execute(f"SELECT * FROM {table_name} WHERE userid = %s OR roll_no = %s", (userid, roll_no))
            if cursor.fetchone():
                return f"❌ Student already exists in class {class_name} with this User ID or Roll Number!"
            insert_student_query = f"""
                INSERT INTO {table_name} (name, userid, roll_no, password, photo) 
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(insert_student_query, (name, userid, roll_no, password, photo))
            conn.commit()
        return f"✅ {role} Registration Successful in {class_name if role == 'User' else 'Admin Panel'}!"
    except mysql.connector.Error as err:
        print(f"❌ Database Error: {err}")
        return f"❌ Database Error: {err}"
    finally:
        cursor.close()
        conn.close()
def verify_login(userid, password, role, class_name=None):
    conn = connect_db()
    if not conn:
        return None
    cursor = conn.cursor()
    try:
        if role == "Admin":
            cursor.execute("SELECT * FROM admin WHERE userid = %s AND password = %s", (userid, password))
        else:  # User login
            if not class_name:
                return None 
            table_name = class_name.replace(" ", "_")
            cursor.execute(f"SELECT * FROM {table_name} WHERE userid = %s AND password = %s", (userid, password))
        return cursor.fetchone()
    except mysql.connector.Error as err:
        print(f"Login Error: {err}")
        return None
    finally:
        cursor.close()
        conn.close()
def get_student_photo(roll_no, class_name):
    conn = connect_db()
    if not conn:
        return None
    cursor = conn.cursor()
    try:
        table_name = class_name.replace(" ", "_")
        query = f"SELECT photo FROM {table_name} WHERE roll_no = %s"
        cursor.execute(query, (roll_no,))
        result = cursor.fetchone()
        if result:
            return result[0]
        return None
    except mysql.connector.Error as err:
        print(f"Error fetching student photo from {class_name}: {err}")
        return None
    finally:
        cursor.close()
        conn.close()
def mark_attendance(roll_no, class_name, date):
    conn = connect_db()
    if not conn:
        return False
    cursor = conn.cursor()
    try:
        table_name = class_name.replace(" ", "_")
        cursor.execute(f"""
            SELECT COUNT(*) FROM information_schema.tables 
            WHERE table_schema = DATABASE() AND table_name = %s
        """, (table_name,))
        if cursor.fetchone()[0] == 0:
            print(f"Error: Class '{class_name}' does not exist.")
            return False
        cursor.execute(f"SELECT * FROM {table_name} WHERE roll_no = %s", (roll_no,))
        if not cursor.fetchone():
            print(f"Error: Student with Roll No. {roll_no} not found in class {class_name}.")
            return False
        cursor.execute(
            "SELECT * FROM attendance WHERE roll_no = %s AND class_name = %s AND date = %s",
            (roll_no, class_name, date)
        )
        if cursor.fetchone():
            return True 
        cursor.execute(
            "INSERT INTO attendance (roll_no, class_name, date, status) VALUES (%s, %s, %s, 'Present')",
            (roll_no, class_name, date)
        )
        conn.commit()
        return True
    except mysql.connector.Error as err:
        print(f"Error marking attendance: {err}")
        return False
    finally:
        cursor.close()
        conn.close()
def get_attendance_report(class_name, date=None):
    conn = connect_db()
    if not conn:
        return None
    cursor = conn.cursor(dictionary=True)
    try:
        table_name = class_name.replace(" ", "_")
        cursor.execute(f"""
            SELECT COUNT(*) FROM information_schema.tables 
            WHERE table_schema = DATABASE() AND table_name = %s
        """, (table_name,))
        if cursor.fetchone()["COUNT(*)"] == 0:
            print(f"❌ Error: Class '{class_name}' does not exist.")
            return None
        if not date:
            date_query = "AND DATE(a.date_time) = CURDATE()"
        else:
            date_query = "AND DATE(a.date_time) = %s"
        query = f"""
            SELECT s.roll_no, s.name, COALESCE(a.date_time, %s) AS date, COALESCE(a.status, 'Absent') AS status
            FROM {table_name} s
            LEFT JOIN attendance a 
            ON s.roll_no = a.roll_no AND a.class_name = %s {date_query}
            ORDER BY s.roll_no, a.date_time
        """
        params = [date if date else "No Record", class_name]
        if date:
            params.append(date)
        cursor.execute(query, tuple(params))
        return cursor.fetchall()
    except mysql.connector.Error as err:
        print(f"❌ Error fetching attendance report: {err}")
        return None
    finally:
        cursor.close()
        conn.close()
def get_all_students(class_name):
    """Fetches all students enrolled in a specific class."""
    conn = connect_db()
    cursor = conn.cursor()
    
    try:
        table_name = class_name.replace(" ", "_")
        query = f"SELECT roll_no, name FROM {table_name}"
        cursor.execute(query, (table_name,))
        students = cursor.fetchall()  # List of tuples (roll_no, name)
    except Exception as e:
        print(f"Database Error: {e}")
        students = []
    
    conn.close()
    return students
def create_or_reset_attendance_record():
    conn = connect_db()
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS attendance_record (
            name varchar(10),
            roll_no int,
            remark varchar(10)
        )
    ''')
    c.execute('DELETE FROM attendance_record')
    conn.commit()
    conn.close()

def fetch_attendance_record():
    conn = connect_db()
    df = pd.read_sql_query("SELECT * FROM attendance_record", conn)
    conn.close()
    return df