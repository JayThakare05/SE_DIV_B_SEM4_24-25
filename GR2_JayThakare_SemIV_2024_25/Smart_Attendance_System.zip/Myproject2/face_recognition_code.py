import streamlit as st
import cv2
import mysql.connector
import os
import time
import face_recognition
from save_excel import save_attendance_to_excel
TEMP_IMAGE_FOLDER = "temp_student_images"
os.makedirs(TEMP_IMAGE_FOLDER, exist_ok=True)
EXCEL_FOLDER = "Excel"
os.makedirs(EXCEL_FOLDER, exist_ok=True)
def convert_blob_to_image(blob_data, roll_no):
    try:
        image_path = os.path.join(TEMP_IMAGE_FOLDER, f"{roll_no}.jpg")
        with open(image_path, "wb") as file:
            file.write(blob_data)
        return image_path
    except Exception as e:
        st.error(f"⚠ Failed to convert image: {str(e)}")
        return None
def ensure_attendance_table(class_name, subject, date, hrs):
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Jay@1509",
            database="smart_attendance",
            auth_plugin="mysql_native_password"
        )
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                roll_no VARCHAR(20) PRIMARY KEY,
                name VARCHAR(255),
                total INT DEFAULT 0
            )
        """)
        column_name = f"{subject}_{date.replace('-', '_')}"
        cursor.execute(f"SHOW COLUMNS FROM attendance LIKE '{column_name}'")
        result = cursor.fetchone()
        if not result:
            cursor.execute(f"ALTER TABLE attendance ADD COLUMN `{column_name}` VARCHAR(10) DEFAULT 'Absent'")
            cursor.execute(f"ALTER TABLE attendance ADD COLUMN `{column_name}_duration` FLOAT DEFAULT {hrs}")
            conn.commit()
        cursor.close()
        conn.close()
    except mysql.connector.Error as err:
        st.error(f"❌ Database Error: {err}")
def mark_attendance(roll_no, class_name, subject, date):
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Jay@1509",
            database="smart_attendance",
            auth_plugin="mysql_native_password"
        )
        cursor = conn.cursor()
        column_name = f"{subject}_{date.replace('-', '_')}"
        cursor.execute(f"""
            UPDATE attendance 
            SET `{column_name}` = 'Present', total = total + 1 
            WHERE roll_no = %s
        """, (roll_no,))
        conn.commit()
        cursor.close()
        conn.close()
    except mysql.connector.Error as err:
        st.error(f"❌ Database Error: {err}")
def capture_attendance(class_name, date, hrs, subject, time_str):
    st.title("📸 Face Recognition Attendance")
    stop_button = st.button("🛑 Stop Recognition")
    status_placeholder = st.empty()
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Jay@1509",
            database="smart_attendance",
            auth_plugin="mysql_native_password"
        )
        cursor = conn.cursor()
        table_name = class_name.replace(" ", "_").replace("-", "_")
        cursor.execute(f"SELECT roll_no, name, photo FROM {table_name}")
        students_data = cursor.fetchall()
        cursor.close()
        conn.close()
        student_encodings = {}
        for roll_no, name, photo_blob in students_data:
            if photo_blob:
                image_path = convert_blob_to_image(photo_blob, roll_no)
                image = face_recognition.load_image_file(image_path)
                face_encodings = face_recognition.face_encodings(image)
                if face_encodings:
                    student_encodings[roll_no] = (name, face_encodings[0])
        if not student_encodings:
            st.error("❌ No valid student images found.")
            return
        ensure_attendance_table(class_name, subject, date, hrs)
        video_capture = cv2.VideoCapture(0)
        if not video_capture.isOpened():
            st.error("❌ Error: Could not open camera.")
            return
        stframe = st.empty()
        attendance_status = st.empty()
        status_placeholder.success("✅ Face recognition started. Look at the camera to mark attendance.")
        max_time = time.time() + 60 
        present_students = set()
        while time.time() < max_time:
            if stop_button:
                status_placeholder.info("🛑 Recognition stopped by user.")
                break
            ret, frame = video_capture.read()
            if not ret:
                continue
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(frame_rgb)
            face_encodings = face_recognition.face_encodings(frame_rgb, face_locations)
            for face_encoding in face_encodings:
                for roll_no, (name, stored_encoding) in student_encodings.items():
                    match = face_recognition.compare_faces([stored_encoding], face_encoding, tolerance=0.5)
                    if match[0] and roll_no not in present_students:
                        present_students.add(roll_no)
                        mark_attendance(roll_no, class_name, subject, date)
                        status_placeholder.success(f"✅ {name}'s attendance marked Present")
            stframe.image(frame_rgb, channels="RGB")
            attendance_status.info(f"📊 Attendance: {len(present_students)}/{len(student_encodings)} students present")
        video_capture.release()
        stframe.empty()
        attendance_status.empty()
        final_attendance = [(roll_no, "Present") for roll_no in present_students]
        all_students = set(student_encodings.keys())
        absent_students = all_students - present_students
        for roll_no in absent_students:
            final_attendance.append((roll_no, "Absent"))
        try:
            file_path = save_attendance_to_excel(class_name, date, hrs, subject, final_attendance)
            st.success(f"📁 Attendance saved in: {file_path}")
        except Exception as e:
            st.error(f"❌ Failed to save attendance: {str(e)}")
    except mysql.connector.Error as db_error:
        st.error(f"❌ Database error: {db_error}")
    except Exception as e:
        st.error(f"❌ An error occurred: {str(e)}")