import streamlit as st
import io
from PIL import Image
from db import connect_db, mark_attendance
from save_excel import save_attendance_to_excel
import os
import pandas as pd
def student_panel():
    st.title("🎓 Student Dashboard")
    st.subheader(f"Welcome, {st.session_state.userid}!")
    class_name = st.session_state.class_name
    student_data = get_student_data(st.session_state.userid,class_name)
    if not student_data:
        st.error("❌ Unable to fetch your profile data. Please contact admin.")
        return
    tab1, tab2, tab3 = st.tabs(["📊 My Profile", "📷 Scan QR", "📅 Attendance History"])
    with tab1:
        col1, col2 = st.columns([1, 2])
        with col1:
            if student_data["photo"]:
                img = Image.open(io.BytesIO(student_data["photo"]))
                st.image(img, caption="Your Profile Photo", width=200)
            else:
                st.info("No profile photo available")
        with col2:
            st.markdown(f"**Name:** {student_data['name']}")
            st.markdown(f"**Student ID:** {student_data['userid']}")
            st.markdown(f"**Roll Number:** {student_data['roll_no']}")
            st.markdown(f"**Class:** {class_name}")
    with tab2:
        st.subheader("Scan QR Code to Mark Attendance")
        if st.button("📷 Start QR Scanner"):
            scan_qr_and_mark_attendance(student_data["roll_no"], student_data["name"], class_name)
    with tab3:
        st.subheader("📅 My Attendance Records")
        attendance_history = get_attendance_history(student_data["roll_no"], class_name)
        if attendance_history:
            import pandas as pd
            df = pd.DataFrame(attendance_history, columns=["Subject", "Date", "Time", "Hours", "Status"])
            present_count = len(df[df['Status'] == 'Present'])
            total_classes = len(df)
            attendance_percent = (present_count / total_classes * 100) if total_classes > 0 else 0
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Total Classes", total_classes)
            with col2:
                st.metric("Attendance Percentage", f"{attendance_percent:.1f}%")
            st.dataframe(df)
        else:
            st.info("No attendance records found.")
    if st.sidebar.button("💙 Logout"):
        st.session_state.page = "Login"
        st.session_state.logged_in = False
        st.session_state.role = None
        st.rerun()
    
def get_student_data(userid,class_name):
    try:
        conn = connect_db()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute(f"SELECT name, userid, roll_no, photo FROM {class_name} WHERE userid = %s", (userid,))
        result = cursor.fetchone()
        cursor.close()
        conn.close()
        return result
    except Exception as e:
        st.error(f"Database Error: {e}")
        return None
def scan_qr_and_mark_attendance(roll_no, name, class_name):
    qr_scanner_html = """
    <!DOCTYPE html>
    <html>
    <head>
        <script src="https://unpkg.com/@zxing/library@latest"></script>
    </head>
    <body>
        <video id="video" width="100%" height="auto" style="border: 2px solid black;"></video>
        <p id="output">Scanning...</p>
        
        <script>
            const codeReader = new ZXing.BrowserQRCodeReader();
            const videoElement = document.getElementById('video');
            const outputElement = document.getElementById('output');

            navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }).then((stream) => {
                videoElement.srcObject = stream;
                videoElement.setAttribute("playsinline", true);
                videoElement.play();

                codeReader.decodeFromVideoDevice(undefined, videoElement, (result, err) => {
                    if (result) {
                        outputElement.innerText = "QR Scanned: " + result.text;
                        videoElement.srcObject.getTracks().forEach(track => track.stop());
                        fetch("/?scanned_qr=" + encodeURIComponent(result.text));
                        alert("✅ Attendance Marked: " + result.text);
                    }
                });
            }).catch((err) => {
                outputElement.innerText = "Error: " + err.message;
            });
        </script>
    </body>
    </html>
    """
    st.components.v1.html(qr_scanner_html, height=400)

    scanned_qr = st.query_params.get("scanned_qr", "")
    if scanned_qr:
        try:
            date, subject, time_str = scanned_qr.split("|")
            file_name = f"{class_name}_{date}_{subject}_1hr.xlsx"
            file_path = os.path.join("Excel", class_name, file_name)

            # Mark attendance in Excel file
            if os.path.exists(file_path):
                df = pd.read_excel(file_path)
                df.loc[df["Roll No"] == roll_no, "Status"] = "Present"
                df.to_excel(file_path, index=False)

                # Insert into attendance_record table
                try:
                    conn = connect_db()
                    if conn:
                        cursor = conn.cursor()
                        cursor.execute(
                            "INSERT INTO attendance_record (name, roll_no, remark) VALUES (%s, %s, %s)",
                            (name, roll_no, "Present")
                        )
                        conn.commit()
                        cursor.close()
                        conn.close()
                except Exception as db_err:
                    st.error(f"📛 DB Error (insert into attendance_record): {db_err}")

                st.success(f"✅ Attendance Marked for {name} in {subject}")
            else:
                st.error("❌ Attendance sheet not found. Contact admin.")
        except Exception as e:
            st.error(f"⚠️ Invalid QR Code format: {e}")

def get_attendance_history(roll_no, class_name):
    try:
        conn = connect_db()
        if not conn:
            return []
        cursor = conn.cursor()
        cursor.execute("SELECT  id,roll_no, date_time, status, total FROM attendance WHERE roll_no = %s AND class_name = %s ORDER BY date_time DESC", (roll_no, class_name))
        history = cursor.fetchall()
        cursor.close()
        conn.close()
        return history
    except Exception as e:
        st.error(f"Error fetching attendance records: {e}")
        return []
